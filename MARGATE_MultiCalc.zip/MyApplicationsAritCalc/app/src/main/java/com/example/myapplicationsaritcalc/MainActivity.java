package com.example.myapplicationsaritcalc;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView information;
    private TextView result;
    private Button btnParenthesesLeft, btnParenthesesRight, btnPercentage, btn7, btn8, btn9, btn4, btn5, btn6,
            btn1, btn2, btn3, btn0, btnDecimal, btnEqual, btnPlus, btnMinus, btnMultiply, btnDivide, btnClear;

    private final char ADDITION = '+';
    private final char DIVISION = '/';
    private final char SUBTRACTION = '-';
    private final char MULTIPLICATION = '*';
    private final char EQU = 0;

    private double val1 = Double.NaN;
    private double val2;
    private char ACTION;

    ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aclayout);

        setupUIViews();

        btn0.setOnClickListener(view -> information.setText(information.getText().toString() + "0"));
        btn1.setOnClickListener(view -> information.setText(information.getText().toString() + "1"));
        btn2.setOnClickListener(view -> information.setText(information.getText().toString() + "2"));
        btn3.setOnClickListener(view -> information.setText(information.getText().toString() + "3"));
        btn4.setOnClickListener(view -> information.setText(information.getText().toString() + "4"));
        btn5.setOnClickListener(view -> information.setText(information.getText().toString() + "5"));
        btn6.setOnClickListener(view -> information.setText(information.getText().toString() + "6"));
        btn7.setOnClickListener(view -> information.setText(information.getText().toString() + "7"));
        btn8.setOnClickListener(view -> information.setText(information.getText().toString() + "8"));
        btn9.setOnClickListener(view -> information.setText(information.getText().toString() + "9"));
        btnPlus.setOnClickListener(view -> information.setText(information.getText().toString() + "+"));
        btnParenthesesLeft.setOnClickListener(view -> information.setText(information.getText().toString() + "("));
        btnParenthesesRight.setOnClickListener(view -> information.setText(information.getText().toString() + ")"));
        btnPercentage.setOnClickListener(view -> information.setText(information.getText().toString() + "%"));


        btnPlus.setOnClickListener(view -> {
            compute();
            ACTION = ADDITION;
            result.setText(val1 + "+");
            information.setText("");
        });
        btnMinus.setOnClickListener(view -> {
            compute();
            ACTION = SUBTRACTION;
            result.setText(val1 + "-");
            information.setText("");
        });
        btnMultiply.setOnClickListener(view -> {
            compute();
            ACTION = MULTIPLICATION;
            result.setText(val1 + "*");
            information.setText("");
        });
        btnDivide.setOnClickListener(view -> {
            compute();
            ACTION = MULTIPLICATION;
            result.setText(val1 + "/");
            information.setText("");
        });

        btnEqual.setOnClickListener(new View.OnClickListener()   {
            @Override

            public void onClick(View v) {
                compute();
                ACTION = EQU;
                result.setText(result.getText().toString() + String.valueOf(val2) + "=" + String.valueOf(val1));
                information.setText(null);
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener()   {
            @Override

            public void onClick(View v) {
                if(information.getText().length()>0) {
                    CharSequence name = information.getText().toString();
                    information.setText(name.subSequence(0, name.length() - 1));
                }
                else
                {
                    val1 = Double.NaN;
                    val2 = Double.NaN;
                    information.setText(null);
                    result.setText(null);
                }
            }
        });
    }



    private void setupUIViews(){


        information = findViewById(R.id.information);
        result = findViewById(R.id.Result);
        btnParenthesesLeft = findViewById(R.id.btnParenthesesLeft);
        btnParenthesesRight = findViewById(R.id.btnParenthesesRight);
        btnPercentage = findViewById(R.id.btnPercentage);
        btn9 = findViewById(R.id.btn9);
        btn8 = findViewById(R.id.btn8);
        btn7 = findViewById(R.id.btn7);
        btn6 = findViewById(R.id.btn6);
        btn5 = findViewById(R.id.btn5);
        btn4 = findViewById(R.id.btn4);
        btn3 = findViewById(R.id.btn3);
        btn2 = findViewById(R.id.btn2);
        btn1 = findViewById(R.id.btn1);
        btn0 = findViewById(R.id.btn0);
        btnDecimal = findViewById(R.id.btnDecimal);
        btnEqual = findViewById(R.id.btnEqual);
        btnPlus = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        btnClear = findViewById(R.id.btnClear);





    }
    private void compute() {
        try {
            String input = information.getText().toString().trim();
            if (!input.isEmpty()) {
                val2 = Double.parseDouble(input);

                if (!Double.isNaN(val1)) {
                    switch (ACTION) {
                        case ADDITION:
                            val1 += val2;
                            break;
                        case SUBTRACTION:
                            val1 -= val2;
                            break;
                        case MULTIPLICATION:
                            val1 *= val2;
                            break;
                        case DIVISION:
                            val1 /= val2;
                            break;
                        case EQU:
                            break;
                    }
                } else {
                    val1 = val2;
                }
            } else {
                result.setText("Invalid input");
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            result.setText("Invalid input");
        }
    }

    @Override
    public void onClick(View view) {

    }
}





